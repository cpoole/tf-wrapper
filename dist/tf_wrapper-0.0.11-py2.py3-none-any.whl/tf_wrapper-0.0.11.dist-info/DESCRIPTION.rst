tf -environment prod -action plan

create a file for each environment labeled <environment>.tf under the environments folder



